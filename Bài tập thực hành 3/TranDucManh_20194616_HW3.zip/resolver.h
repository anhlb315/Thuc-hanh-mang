#include "account.h"

void print_domain_name(Account* account);
void print_ip_address(Account* account);